<?php
/**
 * Displays Site info
 */
?>

<div class="copyright">
   <p><?php echo esc_html(get_theme_mod('lighting_store_footer_copy',__('Lighting Store WordPress Theme By LogicalThemes','lighting-store'))); ?></p>
</div>

