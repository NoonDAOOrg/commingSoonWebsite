<?php $icons = array();
$icons['icomoon-hero-icons05']['wpb01'] = array('class'=>'wpb01','tags'=>'wpb01','unicode'=>'');
$icons['icomoon-hero-icons05']['elem'] = array('class'=>'elem','tags'=>'elem','unicode'=>'');
$icons['icomoon-hero-icons05']['elem01'] = array('class'=>'elem01','tags'=>'elem01','unicode'=>'');